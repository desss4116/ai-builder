module ai-builder

go 1.22
