package main

import (
    "encoding/json"
    "fmt"
    "net/http"
)

type GenerateRequest struct {
    Prompt string `json:"prompt"`
}

func healthHandler(w http.ResponseWriter, r *http.Request) {
    json.NewEncoder(w).Encode(map[string]string{
        "status": "online",
    })
}

func generateHandler(w http.ResponseWriter, r *http.Request) {
    var req GenerateRequest
    json.NewDecoder(r.Body).Decode(&req)

    json.NewEncoder(w).Encode(map[string]string{
        "result": "Generated project for: " + req.Prompt,
    })
}

func main() {
    http.HandleFunc("/", healthHandler)
    http.HandleFunc("/generate", generateHandler)

    fmt.Println("Running on :8080")
    http.ListenAndServe(":8080", nil)
}
