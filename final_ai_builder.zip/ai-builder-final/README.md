# AI Builder

AI Builder scaffold using:
- Cloudflare
- GitHub
- Discord
- Go backend
- React-ready frontend

This is a clean starter architecture.
