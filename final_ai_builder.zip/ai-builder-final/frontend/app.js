async function generate() {
  const output = document.getElementById("output");
  output.innerText = "AI generation initialized...";
}
