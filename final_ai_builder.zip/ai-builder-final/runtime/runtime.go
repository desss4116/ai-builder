package runtime

func Start() {}
