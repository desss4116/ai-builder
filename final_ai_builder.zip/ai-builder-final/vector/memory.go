package vector

type Memory struct {
    Entries []string
}
