package rag

func Retrieve(query string) string {
    return query
}
