package vector

import "strings"

func Rank(
	query string,
	data []string,
) []string {

	var ranked []string

	for _, item := range data {

		if strings.Contains(
			strings.ToLower(item),
			strings.ToLower(query),
		) {

			ranked = append(
				ranked,
				item,
			)
		}
	}

	if len(ranked) == 0 {
		return data
	}

	return ranked
}
