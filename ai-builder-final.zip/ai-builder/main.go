package main

import (
	"ai-builder/builder"
	"ai-builder/brain"
	"ai-builder/internet"
	"ai-builder/rag"
	"ai-builder/runtime"
	"ai-builder/vector"
	"fmt"
	"os"

	"github.com/bwmarrin/discordgo"
)

func main() {

	token := os.Getenv("DISCORD_TOKEN")

	dg, err := discordgo.New(
		"Bot " + token,
	)

	if err != nil {
		panic(err)
	}

	dg.AddHandler(messageCreate)

	err = dg.Open()

	if err != nil {
		panic(err)
	}

	fmt.Println("AI Builder Online")

	select {}
}

func messageCreate(
	s *discordgo.Session,
	m *discordgo.MessageCreate,
) {

	if m.Author.Bot {
		return
	}

	s.ChannelMessageSend(
		m.ChannelID,
		"🧠 Анализирую запрос...",
	)

	query :=
		brain.Normalize(
			m.Content,
		)

	searchResults :=
		internet.Search(query)

	if len(searchResults) == 0 {

		s.ChannelMessageSend(
			m.ChannelID,
			"❌ Ничего не найдено.",
		)

		return
	}

	intent :=
		rag.ExtractIntent(query)

	ranked :=
		vector.Rank(
			query,
			searchResults,
		)

	answer :=
		brain.Synthesize(
			intent,
			ranked,
		)

	answer =
		runtime.Validate(answer)

	final :=
		builder.Format(answer)

	if len(final) > 1900 {
		final = final[:1900]
	}

	s.ChannelMessageSend(
		m.ChannelID,
		final,
	)
}
