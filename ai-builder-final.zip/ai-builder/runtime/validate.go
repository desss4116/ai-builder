package runtime

import "strings"

func Validate(
	text string,
) string {

	text =
		strings.ReplaceAll(
			text,
			"🌐 Ответ:\n\n🌐 Ответ:",
			"🌐 Ответ:",
		)

	return text
}
