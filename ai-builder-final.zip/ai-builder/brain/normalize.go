package brain

import "strings"

func Normalize(input string) string {

	input =
		strings.ToLower(input)

	replacer := strings.NewReplacer(
		"ё", "е",
		"й", "и",
	)

	input = replacer.Replace(input)

	input =
		strings.TrimSpace(input)

	return input
}
