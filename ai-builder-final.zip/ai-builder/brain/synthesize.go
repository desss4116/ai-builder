package brain

import "strings"

func Synthesize(
	intent string,
	data []string,
) string {

	if len(data) == 0 {
		return ""
	}

	var result strings.Builder

	result.WriteString(
		"🌐 Ответ:\n\n",
	)

	for i, item := range data {

		if i >= 5 {
			break
		}

		item =
			strings.TrimSpace(item)

		if len(item) < 30 {
			continue
		}

		result.WriteString(item)
		result.WriteString("\n\n")
	}

	return result.String()
}
