package builder

func Format(
	text string,
) string {

	return text
}
