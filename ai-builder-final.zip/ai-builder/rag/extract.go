package rag

import "strings"

func ExtractIntent(
	query string,
) string {

	query =
		strings.ToLower(query)

	if strings.Contains(
		query,
		"сделай",
	) {
		return "build"
	}

	if strings.Contains(
		query,
		"кто",
	) {
		return "person"
	}

	if strings.Contains(
		query,
		"что",
	) {
		return "explain"
	}

	return "search"
}
