package internet

import (
	"io"
	"net/http"
	"net/url"
	"strings"
	"time"

	"github.com/PuerkitoBio/goquery"
)

func Search(query string) []string {

	client := &http.Client{
		Timeout: 10 * time.Second,
	}

	searchURL :=
		"https://html.duckduckgo.com/html/?q=" +
			url.QueryEscape(query)

	req, _ := http.NewRequest(
		"GET",
		searchURL,
		nil,
	)

	req.Header.Set(
		"User-Agent",
		"Mozilla/5.0",
	)

	resp, err := client.Do(req)

	if err != nil {
		return nil
	}

	defer resp.Body.Close()

	body, _ := io.ReadAll(resp.Body)

	doc, err :=
		goquery.NewDocumentFromReader(
			strings.NewReader(
				string(body),
			),
		)

	if err != nil {
		return nil
	}

	results := []string{}

	doc.Find("a").Each(func(
		i int,
		s *goquery.Selection,
	) {

		text :=
			strings.TrimSpace(
				s.Text(),
			)

		if len(text) > 40 {

			results = append(
				results,
				text,
			)
		}
	})

	return results
}
